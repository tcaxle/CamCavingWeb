Notes from 05/2018 Inventory:
- All oversuits relabelled and numbered
- Gloves paired or thrown if single
- Helmets checked and unsafe ones disposed of
- Tackle store tidied and floor fecklessly swept
- All non "regular" tackle relocated to attic
- Rope checked, washed, listed ahead of 2018 Expo
- Maillons checked and listed ahead of 2018 Expo
- Doom Rope of suitable length saved for SRT rope cutting rescue practice but stored upstairs to avoid 
accidental Unserground Use
- Lead Acid Kit piled ready for responsible disposal
- All books and paper records moved to attic to avoid damp
- Some kit not yet counted as it's in Wookey's van:

	- 1 small warmbac tacklesack
	- 7 slings
	- 1 rope protector
	- 1 bolting hammer
	- 1 setter
	- 6 maillions
	- 10 ring hangers

- Wookey also has the drill, 3 chargers and all the batts
- Need to go back and recheck slings as only 5 listed and there are definitely more than 5
- Need to count belts for OCD reasons
- Need to gear tape SRT kits
- Need to retag all rope with heat shrink and Polish bands length-system
- Need to contact UL to see if we can offload old log books for safekeeping
- Need to count Lights and Batteries
